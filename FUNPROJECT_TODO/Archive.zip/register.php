<?php
	require_once 'app/init.php';

	$username = $password = $confirm_password = "";
	$username_err = $password_err = "";

	if(!empty($_SESSION['user_id'])) {
		header("location: index.php");
		die("already signed in.");
	} elseif($_SERVER['REQUEST_METHOD'] == 'POST'){
		//Check Username
		if (empty(trim($_POST['username']))) {
			$username_err = "Please enter a username.";
		} else {
			$username = trim($_POST['username']);
			$check = "SELECT username FROM users
		    WHERE username = :username";
			$sth = $db->prepare($check);
			$sth->bindValue(':username', $username, PDO::PARAM_STR);
	    $sth->execute();
	    $result = $sth->fetchColumn();
			if (!empty($result)) {
				$username_err = "There is already such user.";
			}
		}
		//Check Password
		if (!empty(trim($_POST['password'])) && !empty(trim($_POST['passwordconfirm']))) {
			$password = trim($_POST['password']);
			$confirm_password = trim($_POST['passwordconfirm']);
			if ($password !== $confirm_password) {
				$password_err = "Password did not match.";
			}
		} else {
			$password_err = "Please enter a password.";
		}

		//Create New User
		if (empty($username_err) && empty($password_err)) {
			$insert = "INSERT INTO users (username, password, user_id)
				VALUES (:username, :password, UUID())";
			$options = [
				'cost' => 12,
			];
			$password = password_hash($password, PASSWORD_DEFAULT, $options);
			$sth = $db->prepare($insert);
			$sth->bindValue(':username', $username, PDO::PARAM_STR);
			$sth->bindValue(':password', $password, PDO::PARAM_STR);
			$sth->execute();
			//Set Session
			$getID = "SELECT user_id FROM users
				WHERE username = :username";
			$sth = $db->prepare($getID);
			$sth->bindValue(':username', $username, PDO::PARAM_STR);
			$sth->execute();
			$resultID = $sth->fetchColumn();
			if (!empty($resultID)) {
				$_SESSION['user_id'] = $resultID;
				header("location: index.php");
			}
		}
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
	<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
	<link rel="manifest" href="assets/favicons/site.webmanifest">
	<link rel="mask-icon" href="assets/favicons/safari-pinned-tab.svg" color="#5bbad5">
	<link rel="shortcut icon" href="assets/favicons/favicon.ico">
	<meta name="msapplication-TileColor" content="#2b5797">
	<meta name="msapplication-config" content="assets/favicons/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,700" rel="stylesheet">
	<link rel="stylesheet" href="assets/stylesheets/main.css">
	<title>PHP Webpage: To Do</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
	<div class="preloader">
		<p>loading...</p>
	</div>
	<section class="todo signing">
		<div class="lists">
			<div>
				<div class="head">
					<h1>register</h1>
				</div>
				<form method="post">
					<!-- User Information -->
					<div>
						<div class="flex">
							<div class="icon"><img src="assets/img/icons/user.svg" alt="profile"></div>
							<input autofocus type="text" name="username" placeholder="Username" value="<?php echo $username; ?>">
						</div>
						<?php if (!empty($username_err)): ?>
							<div class="warning">
								<?php echo $username_err; ?>
							</div>
						<?php endif; ?>
					</div>
					<!-- Password -->
					<div>
						<div class="flex">
							<div class="icon"><img src="assets/img/icons/lock.svg" alt="password"></div>
							<input type="password" name="password" placeholder="Password">
						</div>
						<div class="flex">
							<div class="icon"><img src="assets/img/icons/confirmlock.svg" alt="confirm"></div>
							<input type="password" name="passwordconfirm" placeholder="Repeat password">
						</div>
						<?php if (!empty($password_err)): ?>
							<div class="warning">
								<?php echo $password_err; ?>
							</div>
						<?php endif; ?>
					</div>
					<!-- Submit -->
					<button type="submit"><span class="fill"></span><span>sign up</span></button>
				</form>
				<p class="question"><a href="login.php">Already have an account?</a></p>
			</div>
		</div>
		<div class="copyright">Ⓒ Josias Ribi 2018, All Rights Reserved.</div>
	</section>
	<script src="assets/js/main.js">
	</script>
</body>
</html>
