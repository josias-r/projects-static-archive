<?php
	require_once 'app/init.php';

	// Login Check
	if(empty($_SESSION['user_id'])) {
		header("location: login.php");
		die("not signed in.");
	} else {
		$user = $_SESSION['user_id'];


		$getUserName = $db->prepare("
			SELECT username
			FROM users
			WHERE user_id = :userid
		");
		$getUserName->bindValue(':userid', $user, PDO::PARAM_STR);
		$getUserName->execute();
		$username = $getUserName->fetchColumn();


		$listQuery = $db->prepare("
			SELECT *
			FROM lists LEFT JOIN items ON items.list_id = lists.list_id
			WHERE lists.user_id = :userid AND lists.folder_id <=> :folderid
			ORDER BY lists.list_id
		");


		$folderCheck = true;
		if (!empty($_GET['folder'])) {
			$folderid = $_GET['folder'];
			$check = "SELECT * FROM folders WHERE user_id = :userid AND folder_id = :folderid";
			$sth = $db->prepare($check);
			$sth->bindValue(':userid', $user, PDO::PARAM_STR);
			$sth->bindValue(':folderid', $folderid, PDO::PARAM_STR);
			$sth->execute();
			$result = $sth->fetch(PDO::FETCH_ASSOC);
			$id = $result['folder_id'];
			if (empty($id)) {
				$folderCheck = false;
			} else {
				while ($id) {
					$check = "SELECT * FROM folders WHERE user_id = :userid AND folder_id = :folderid";
					$sth = $db->prepare($check);
					$sth->bindValue(':userid', $user, PDO::PARAM_STR);
					$sth->bindValue(':folderid', $id, PDO::PARAM_STR);
					$sth->execute();
					$result = $sth->fetch(PDO::FETCH_ASSOC);
					$pathArray[$id] = $result['name'];
					$id = $result['parent_id'];
				}
			}
		} else {
			$folderid = null;
		}

		$listQuery->bindValue(':folderid', $folderid, PDO::PARAM_STR);
		$listQuery->bindValue(':userid', $user, PDO::PARAM_STR);
		$listQuery->execute();

		$lastListID = '';
		while ($recs = $listQuery->fetch(PDO::FETCH_NAMED)) {

			if($recs['list_id']['0'] != $lastListID) {
				$lastListID = $recs['list_id']['0'];
			}
			foreach ($recs as $key => $value) {
				$listArray[$lastListID][$recs['item_id']][$key] = $value;
			}
		}
		// echo '<pre>'; print_r($listArray); echo '</pre>';


		$folderQuery = $db->prepare("
			SELECT *
			FROM folders
			WHERE user_id = :userid AND parent_id <=> :folderid
		");
		$folderQuery->bindValue(':folderid', $folderid, PDO::PARAM_STR);
		$folderQuery->bindValue(':userid', $user, PDO::PARAM_STR);
		$folderQuery->execute();
		$folders = $folderQuery->rowCount() ? $folderQuery : [];
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
	<link rel="apple-touch-icon" sizes="180x180" href="assets/favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/favicons/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/favicons/favicon-16x16.png">
	<link rel="manifest" href="assets/favicons/site.webmanifest">
	<link rel="mask-icon" href="assets/favicons/safari-pinned-tab.svg" color="#5bbad5">
	<link rel="shortcut icon" href="assets/favicons/favicon.ico">
	<meta name="msapplication-TileColor" content="#2b5797">
	<meta name="msapplication-config" content="assets/favicons/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,700" rel="stylesheet">
	<link rel="stylesheet" href="assets/stylesheets/main.css">
	<title>PHP Webpage: To Do</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
	<div class="preloader">
		<p>loading...</p>
	</div>
	<div class="alert">
		<form class="box">
			<h3></h3>
			<span></span>
			<input type="text">
			<button type="submit">
				<span class="fill"></span>
				<span class="value"></span>
			</button>
		</div>
	</form>
	<header>
		<h1>todo</h1>
		<a href="app/logout.php" class="logout">

			<span></span>
		</a>
		<div class="profile">
			<?php echo $username ?>
		</div>
	</header>
	<section class="todo">
		<?php if($folderCheck): ?>
			<div class="path">
				<span data-id="">Home</span>
				<?php if(!empty($pathArray)): ?>
					<?php foreach ( array_reverse($pathArray) as $id => $path): ?>
						<span data-id="<?php echo $id?>">
							<?php echo $path ?>
						</span>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
			<div class="folders">
				<?php if (!empty($folders)): ?>
					<?php foreach ($folders as $folder): ?>
						<div data-id="<?php echo $folder['folder_id'] ?>">
							<h2>
								<?php echo $folder['name'] ?>
							</h2>
							<div class="trash popup">
								<div class="open">
								 <img src="assets/img/icons/trashcan.svg" alt="delete list">
								</div>
								<div class="info">
									 <div class="title">Delete Folder</div>
									 <div class="text">Delete folder and all it's content?</div>
									 <div class="button">confirm</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
				<div class="add popup">
					<div class="open">+</div>
					<div class="info">
						<div class="title">new folder</div>
						<div class="input">Folder name</div>
						<div class="button">create</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
		<div class="lists">
			<?php if (!empty($listArray)): ?>
				<?php foreach ($listArray as $key => $list): ?>
					<div>
						<form class="addItem" action="app/add.php" method="post" data-id="<?php echo $key ?>">
							<input autofocus type="text" name="item" placeholder="Add something here">
							<button type="submit">+</button>
						</form>
						<ul>
							<?php foreach ($list as $item): ?>
								<?php if (!empty($item['item_id'])): ?>
									<li <?php echo $item['done'] ? 'class="done"' : '' ?>>
										<div class="content"><?php echo $item['name'] ?></div>
										<div class="btns" data-id="<?php echo $item['item_id'] ?>">
											<span class="del">+</span>
											<span class="mark"></span>
										</div>
									</li>
								<?php endif; ?>
							<?php endforeach; ?>
						</ul>
						<div class="warning">This list is empty.</div>
						<div class="tools">
	 					 	<div class="trash popup">
								<div class="open">
									<img src="assets/img/icons/trashcan.svg" alt="delete list">
								</div>
								<div class="info">
									<div class="title">delete list</div>
									<div class="text">Delete list and all it's content?</div>
									<div class="button">confirm</div>
								</div>
	 					 	</div>
							<div class="color">
								<div class="open">
									<img src="assets/img/icons/paintbucket.svg" alt="choose color">
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
			<?php if ($folderCheck): ?>
				<div class="warning">
					No lists found. <br>
					Press the button below to create one.
				</div>
				<div class="add">
					<h2>+</h2>
				</div>
			<?php else: ?>
				<div class="warning">
					You seem to have gotten lost. <br>
					<a href="/">go home</a>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<div class="copyright">Ⓒ Josias Ribi 2018, All Rights Reserved.</div>
	<script src="assets/js/main.js">
	</script>
</body>
</html>
