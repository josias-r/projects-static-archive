<?php
	require_once 'init.php';

	if ( !empty($_POST['item']) && !empty($_POST['listid']) && !empty($_SESSION['user_id']) ) {
		$content = $_POST['item'];
		$list_id = $_POST['listid'];
		$user = $_SESSION['user_id'];


		$getuuid = $db->query("SELECT UUID()");
		$uuid = $getuuid->fetchColumn();
		$insert = "INSERT INTO items (name, list_id, item_id)
			VALUES (:content, :list_id, :uuid)";

		if ($sth = $db->prepare($insert)) {
			$sth->bindValue(':content', $content, PDO::PARAM_STR);
			$sth->bindValue(':list_id', $list_id, PDO::PARAM_STR);
			$sth->bindValue(':uuid', $uuid, PDO::PARAM_STR);
			$sth->execute();
			$rsp = array(
				'id'=>$uuid,
				'response'=>'New record created successfully'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
