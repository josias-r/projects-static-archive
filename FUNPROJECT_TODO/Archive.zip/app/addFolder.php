<?php
	require_once 'init.php';

	if (!empty($_POST['name']) && !empty($_SESSION['user_id']) ) {
		$user = $_SESSION['user_id'];

		$folderCheck = true;
		if ( !empty($_POST['parent_id'])) {
			$parent = $_POST['parent_id'];
			$check = "SELECT folder_id FROM folders WHERE user_id = :userid AND folder_id = :folderid";
			$sth = $db->prepare($check);
			$sth->bindValue(':userid', $user, PDO::PARAM_STR);
			$sth->bindValue(':folderid', $parent, PDO::PARAM_STR);
			$sth->execute();
			$result = $sth->fetchColumn();
			if (empty($result)) {
				$folderCheck = false;
			}
		} else {
			$parent = null;
		}

		$foldername = $_POST['name'];


		$insert = "INSERT INTO folders (folder_id, parent_id, name, user_id)
			VALUES (UUID(), :parent, :name, :user)";

		if ($folderCheck && $sth = $db->prepare($insert)) {
			$sth->bindValue(':parent', $parent, PDO::PARAM_STR);
			$sth->bindValue(':name', $foldername, PDO::PARAM_STR);
			$sth->bindValue(':user', $user, PDO::PARAM_STR);
			$sth->execute();
			$rsp = array(
				'response'=>'New folder created successfully'
			);
			print json_encode($rsp);
		} else {
			$rsp = array(
				'response'=>'An error occured on creating a new folder.'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
