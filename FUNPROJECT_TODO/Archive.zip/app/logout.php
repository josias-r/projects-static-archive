<?php
  require_once 'init.php';
  if(!empty($_SESSION['user_id'])) {
    unset($_SESSION['user_id']);
  }
  header('location: ../login.php');
	die("Error: Error logging out.");
?>
