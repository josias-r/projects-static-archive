<?php
	//Sesssion Start
	session_start();
	// Database Connection
	$db = new PDO('mysql:dbname=zegatipe_todo;host=zegatipe.mysql.db.internal','zegatipe_arch','**$vuyvhSe*YC9vV');

	// Check Connection
	// $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>
