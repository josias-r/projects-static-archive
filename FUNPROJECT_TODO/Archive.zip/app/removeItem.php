<?php
	require_once 'init.php';

	if (!empty($_POST['item_id']) && !empty($_SESSION['user_id'])) {
		$id = $_POST['item_id'];
		$user = $_SESSION['user_id'];

		//Delete Item From Database
		$del = "DELETE items FROM items
			INNER JOIN lists ON lists.list_id = items.list_id
			WHERE item_id = :item_id AND lists.user_id = :user_id";

		if ($sth = $db->prepare($del)) {
			$sth->bindValue(':item_id', $id, PDO::PARAM_STR);
			$sth->bindValue(':user_id', $user, PDO::PARAM_STR);
			$sth->execute();
			$rsp = array(
				'response'=>'Record removed successfully.'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
?>
