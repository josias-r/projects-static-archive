<?php
	require_once 'init.php';

	if ( !empty($_SESSION['user_id']) && !empty($_POST['folder_id'])) {
		$user = $_SESSION['user_id'];
		$folderid = $_POST['folder_id'];

		$query = "SELECT *
			FROM folders
			WHERE user_id = :userid AND folder_id = :folderid";
		if ($sth = $db->prepare($query)) {
			$sth->bindValue(':userid', $user, PDO::PARAM_STR);
			$sth->bindValue(':folderid', $folderid, PDO::PARAM_STR);
			$sth->execute();
			$result = $sth->fetch(PDO::FETCH_ASSOC);
			$folderlist[$result['folder_id']] = $result['name'];
			while (!empty($result['folder_id'])) {
				$query = "SELECT *
					FROM folders
					WHERE user_id = :userid AND parent_id = :folderid";
				if ($sth = $db->prepare($query)) {
					$sth->bindValue(':userid', $user, PDO::PARAM_STR);
					$sth->bindValue(':folderid', $result['folder_id'], PDO::PARAM_STR);
					$sth->execute();
					$folderlist[$result['folder_id']] = $result['name'];
					$result = $sth->fetch(PDO::FETCH_ASSOC);
				}
			}
		}
		foreach ($folderlist as $id => $name) {
			$query = "DELETE FROM folders
				WHERE folder_id = :folder_id AND user_id = :user_id";
			if ($sth = $db->prepare($query)){
				$sth->bindValue(':user_id', $user, PDO::PARAM_STR);
				$sth->bindValue(':folder_id', $id, PDO::PARAM_STR);
				$sth->execute();
			}
		}
		$rsp = array(
			'response'=>'Folder and content has been deleted succesfully.'
		);
		print json_encode($rsp);

	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
