<?php
	require_once 'init.php';

	if ( !empty($_SESSION['user_id']) && !empty($_POST['list_id'])) {
		$user = $_SESSION['user_id'];
		$listid = $_POST['list_id'];

		$remove = "DELETE FROM lists
			WHERE list_id = :list_id AND user_id = :user_id";

		if ($sth = $db->prepare($remove)) {

			$sth->bindValue(':list_id', $listid, PDO::PARAM_STR);
			$sth->bindValue(':user_id', $user, PDO::PARAM_STR);

			if ($sth->execute()) {
				$rsp = array(
					'response'=>'The list has been deleted successfully'
				);
				print json_encode($rsp);
			} else {
				$rsp = array(
					'response'=> 'An error occured while executing.'
				);
				print json_encode($rsp);
			}


		} else {
			$rsp = array(
				'response'=> 'An error occured in the prepare statement.'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
