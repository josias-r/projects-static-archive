<?php
	require_once 'init.php';

	if (!empty($_POST['item_id']) && !empty($_SESSION['user_id'])) {
		$id = $_POST['item_id'];
		$user = $_SESSION['user_id'];
		$status = '';

		//Check Current Done Status
		$check = "SELECT items.done
			FROM lists LEFT JOIN items ON items.list_id = lists.list_id
			WHERE items.item_id = :item_id AND lists.user_id = :user_id";

		if ($sth = $db->prepare($check)) {
			$sth->bindValue(':item_id', $id, PDO::PARAM_STR);
			$sth->bindValue(':user_id', $user, PDO::PARAM_STR);
			$sth->execute();
			$status = $sth->fetchColumn();
			$status = $status == 0 ? 1 : 0;
		} else {
			echo "Error: " . $check . "<br>" . $db->error;
		}

		//Update Done Status
		$mark = "UPDATE items
			SET done = :done
			WHERE item_id = :item_id";

		if ($sth = $db->prepare($mark)) {
			$sth->bindValue(':done', $status, PDO::PARAM_INT);
			$sth->bindValue(':item_id', $id, PDO::PARAM_STR);
			$sth->execute();
			$rsp = array(
				'response'=>'An error occured on creating a new list.'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
