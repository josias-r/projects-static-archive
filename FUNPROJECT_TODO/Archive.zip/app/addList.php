<?php
	require_once 'init.php';

	if ( !empty($_SESSION['user_id'])) {

		$user = $_SESSION['user_id'];
		// if ( !empty($_POST['folderid'])) {
		// 	$folder = $_POST['folderid'];
		// } else {
		// 	$folder = null;
		// }

		$folderCheck = true;
		if ( !empty($_POST['folderid'])) {
			$folder = $_POST['folderid'];
			$check = "SELECT folder_id FROM folders WHERE user_id = :userid AND folder_id = :folderid";
			$sth = $db->prepare($check);
			$sth->bindValue(':userid', $user, PDO::PARAM_STR);
			$sth->bindValue(':folderid', $folder, PDO::PARAM_STR);
			$sth->execute();
			$result = $sth->fetchColumn();
			if (empty($result)) {
				$folderCheck = false;
			}
		} else {
			$folder = null;
		}



		$insert = "INSERT INTO lists (folder_id, user_id, list_id)
			VALUES (:folder_id, :user_id, UUID())";

		if ($folderCheck && $sth = $db->prepare($insert)) {
			$sth->bindValue(':folder_id', $folder, PDO::PARAM_STR);
			$sth->bindValue(':user_id', $user, PDO::PARAM_STR);
			$sth->execute();
			$rsp = array(
				'response'=>'New record created successfully'
			);
			print json_encode($rsp);
		} else {
			$rsp = array(
				'response'=>'An error occured on creating a new list.'
			);
			print json_encode($rsp);
		}
	} else {
		unset($_SESSION['user_id']);
		die("Error: Empty request.");
	}
 ?>
